import "./privacy.css";
