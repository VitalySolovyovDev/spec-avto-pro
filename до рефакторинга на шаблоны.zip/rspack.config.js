const path = require("path");
const { defineConfig } = require("@rspack/cli");
const { rspack } = require("@rspack/core");

const rootDir = __dirname;
const distDir = path.resolve(rootDir, "dist");
const srcDir = path.resolve(rootDir, "src");
const assetsDir = path.resolve(srcDir, "assets");

module.exports = defineConfig((_, argv = {}) => {
  const isProd = argv.mode === "production";

  return {
    mode: isProd ? "production" : "development",
    context: rootDir,
    entry: {
      main: path.resolve(srcDir, "index.js"),
      privacy: path.resolve(srcDir, "privacy.js"),
    },
    output: {
      path: distDir,
      clean: true,
      publicPath: "./",
      filename: isProd ? "js/[name].[contenthash:8].js" : "js/[name].js",
    },
    devtool: isProd ? false : "source-map",
    module: {
      rules: [
        {
          test: /\.css$/i,
          type: "javascript/auto",
          use: [
            isProd ? rspack.CssExtractRspackPlugin.loader : "style-loader",
            "css-loader",
          ],
        },
      ],
    },
    plugins: [
      isProd &&
        new rspack.CssExtractRspackPlugin({
          filename: "css/[name].[contenthash:8].css",
        }),
      new rspack.CopyRspackPlugin({
        patterns: [
          {
            from: assetsDir,
            to: "assets",
            noErrorOnMissing: true,
          },
        ],
      }),
      new rspack.HtmlRspackPlugin({
        template: path.resolve(srcDir, "index.html"),
        filename: "index.html",
        chunks: ["main"],
        scriptLoading: "defer",
        minify: isProd,
      }),
      new rspack.HtmlRspackPlugin({
        template: path.resolve(srcDir, "privacy.html"),
        filename: "privacy.html",
        chunks: ["privacy"],
        scriptLoading: "defer",
        minify: isProd,
      }),
    ].filter(Boolean),
    optimization: {
      minimize: isProd,
    },
    devServer: {
      port: 3000,
      hot: true,
      open: true,
      static: {
        directory: assetsDir,
        publicPath: "/assets",
        watch: true,
      },
      watchFiles: [
        "src/**/*.html",
        "src/**/*.js",
        "src/**/*.css",
      ],
      client: {
        overlay: true,
      },
    },
    stats: "errors-warnings",
  };
});
